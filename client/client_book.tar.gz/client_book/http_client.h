/* 
 * File:   http_client.h
 * Author: stefano
 *
 * Created on May 24, 2010, 12:29 PM
 */

#ifndef _HTTP_CLIENT_H
#define	_HTTP_CLIENT_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

char* http_client(char* req_message, char* address, short port);
#endif	/* _HTTP_CLIENT_H */

